import 'dart:convert';
import 'package:http/http.dart' as http;

class PaymentService {
  /// Endpoint server Node.js PayOS webhook bạn đã triển khai
  static const String serverUrl = 'https://payos-server-demo.onrender.com/create-payment-link';

  /// Tạo link thanh toán từ server, nhận về paymentUrl
  static Future<String> createPaymentLink({
    required String userId,
    required String userName,
    required String userEmail,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(serverUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'userId': userId,
          'userName': userName,
          'userEmail': userEmail,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['paymentUrl'] != null) {
          return data['paymentUrl'];
        } else {
          throw Exception('Không nhận được paymentUrl từ server');
        }
      } else {
        throw Exception('Server trả về lỗi: ${response.body}');
      }
    } catch (e) {
      rethrow;
    }
  }
}
